var largura = 750;
var altura = 500;

var corTexto = "#1B1F61"
var corTabuleiro = "#03A6A6";
var corBolinha = "#211840";
var xBolinha = 200;
var yBolinha = 200;
var dBolinha = 20;
var rBolinha = 10;

var velocidadeXBolinha = 6;
var velocidadeYBolinha = 6;

var aRaquete = 100;
var lRaquete = 15;
var vRaquete = 7.5;

var xRaqueteEsquerda = 10;
var yRaqueteEsquerda = ((altura/2) - (aRaquete/2));

var xRaqueteDireita = largura - xRaqueteEsquerda - lRaquete;
var yRaqueteDireita = ((altura/2) - (aRaquete/2));

PontoDireita = 0;
PontoEsquerda = 0;

function setup() {
createCanvas(largura, altura);}


function criarTabuleiro(corTabuleiro){
background(corTabuleiro);}


function Bola(xBolinha, yBolinha, dBolinha, corBolinha){
circle(xBolinha, yBolinha, dBolinha);}

function criarRaqueteEsquerda(xRaqueteEsquerda, yRaqueteEsquerda, lRaquete, aRaquete){
  rect(xRaqueteEsquerda, yRaqueteEsquerda, lRaquete, aRaquete);}
function criarRaqueteDireita(xRaqueteDireita, yRaqueteDireita, lRaquete, aRaquete){
  rect(xRaqueteDireita, yRaqueteDireita, lRaquete, aRaquete);
  }


function movimentarBola(){
  xBolinha = xBolinha + velocidadeXBolinha;
  yBolinha = yBolinha + velocidadeYBolinha;
}


function movimentarRaqueteEsquerda(){
    if (keyIsDown(87)){
      if(yRaqueteEsquerda >= 0){
        yRaqueteEsquerda = yRaqueteEsquerda - vRaquete;}}
  
    if (keyIsDown(83)){
      if (yRaqueteEsquerda <= (altura - aRaquete)){
      yRaqueteEsquerda = yRaqueteEsquerda + vRaquete; }}}


function movimentarRaqueteDireita(){
  if (keyIsDown(UP_ARROW)){
    if(yRaqueteDireita >= 0){
      yRaqueteDireita = yRaqueteDireita - vRaquete;
    }}
  
  if (keyIsDown(DOWN_ARROW))
    if (yRaqueteDireita <= (altura - aRaquete)){
      yRaqueteDireita = yRaqueteDireita + vRaquete;
    } }


function verificarColisaoParede(){
  if (yBolinha >= (altura - rBolinha) || yBolinha < rBolinha){
    velocidadeYBolinha = - velocidadeYBolinha;
    }}


function verificarColisaoRaquete(){
  
  if(xBolinha-rBolinha >= (xRaqueteEsquerda-lRaquete) && xBolinha-rBolinha <= xRaqueteEsquerda) {
     if(yBolinha >= (yRaqueteEsquerda) && yBolinha <= yRaqueteEsquerda + aRaquete) {
     velocidadeXBolinha = - velocidadeXBolinha;
     xBolinha = xRaqueteEsquerda + lRaquete + 1 + rBolinha;
   }}
     
  if( xBolinha + rBolinha >= ( xRaqueteDireita) && xBolinha + rBolinha <= xRaqueteDireita + lRaquete || xBolinha + rBolinha >= (xRaqueteDireita) && xBolinha - rBolinha <= xRaqueteDireita+lRaquete ) {
      

   if(yBolinha >= (yRaqueteDireita) && yBolinha <= yRaqueteDireita+aRaquete) {
        velocidadeXBolinha = - velocidadeXBolinha;
        xBolinha = xRaqueteDireita - 1 - rBolinha;
      } }}

function Pontos() {
textSize(30);
text("JOGADOR 1: "+ pontoEsquerda + (largura/2)-100,22);
text("JOGADOR 2: " + pontoDireita(largura/2)-200,22);
}

function resetarBola(){
  
  if(xBolinha > (largura-rBolinha)){
    xBolinha = 300;
    yBolinha = 200; }
  
  if(xBolinha < rBolinha){
    xBolinha = 300;
    yBolinha = 200; }}


function draw() {
  
criarTabuleiro(corTabuleiro);
  
Bola(xBolinha, yBolinha, dBolinha, corBolinha);
  
criarRaqueteEsquerda(xRaqueteEsquerda, yRaqueteEsquerda, lRaquete, aRaquete);
  
criarRaqueteDireita(xRaqueteDireita, yRaqueteDireita, lRaquete, aRaquete);
  
verificarColisaoParede();
  
movimentarBola();
  
movimentarRaqueteEsquerda();
  
movimentarRaqueteDireita();
  
verificarColisaoRaquete();
  
resetarBola();

Pontos()
  
}